//Project 1 in C - Billing for a Canteen
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
void main()
{
FILE *fp;
int opt,sno=0,price,qty,amount,total=0,items=0;

fp=fopen("Bill.txt","w");
fputs("\t*****Campus Café*****",fp);
fputs("\nBill Details",fp);
fputs("\n------------------------------------------------------------------",fp);
fputs("\nSno\tItem\t\tPrice(Rs.)\tQty\tAmount(Rs.)",fp);
printf("\n\t\tWelcome to Campus Café");
printf("\n\t\t************************");
do
{
printf("\nMenu Card:");
printf("\n---------");
printf("\n1.Chai\t\tRs.50\n2.Coffee\tRs.60\n3.Milk\t\tRs.30\n4.Pasta\tRs.299");
printf("\n5.Momos\tRs.199\n6.Knafeh\tRs.268\n7.tart\tRs.388\n8.Blueberry cheesecake\tRs.499");
printf("\n9.Bill");
printf("\nSelect Your Choice :");
scanf("%d",&opt);
switch(opt)
{
case 1:         //Chai
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tChai\t\t15\t%d\t%d",sno,qty,(15*qty));
total=total+(15*qty);
items=items+qty;
break;
case 2:         //Coffee
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tCoffee\t\t20\t%d\t%d",sno,qty,(20*qty));
total=total+(20*qty);
items=items+qty;
break;
case 3:         //Milk
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tMilk\t\t10\t%d\t%d",sno,qty,(10*qty));
total=total+(10*qty);
items=items+qty;
break;
case 4:         //Pasta
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tPasta\t\t25\t%d\t%d",sno,qty,(25*qty));
total=total+(25*qty);
items=items+qty;
break;
case 5:         //Momos
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tMomos\t\t30\t%d\t%d",sno,qty,(30*qty));
total=total+(30*qty);
items=items+qty;
break;
case 6:         //Knafeh
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tknafeh\t20\t%d\t%d",sno,qty,(20*qty));
total=total+(20*qty);
items=items+qty;
break;
case 7:         //tart
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\ttart\t\t40\t%d\t%d",sno,qty,(40*qty));
total=total+(40*qty);
items=items+qty;
break;
case 8:         //Blueberry cheesecake
printf("Enter the Quantity : ");
scanf("%d",&qty);
sno++;
fprintf(fp,"\n%d\tBlueberry cheese\t45\t%d\t%d",sno,qty,(45*qty));
total=total+(45*qty);
items=items+qty;
break;
case 9:		//Bill
fputs("\n-------------------------------------------------------------------",fp);
fprintf(fp,"\nNo.of Items = %d\t\tTotal Amount = %d",items,total);
fputs("\n-------------------------------------------------------------------",fp);
fclose(fp);
exit(0);
default:
printf("\nInvalid Option");
}
}while(opt!=9);
}
